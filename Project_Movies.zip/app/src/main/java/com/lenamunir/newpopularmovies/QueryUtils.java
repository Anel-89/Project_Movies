package com.lenamunir.newpopularmovies;



public final class QueryUtils {

    private static final String MOVIE_POSTER_JSON_RESPONSE =
}
