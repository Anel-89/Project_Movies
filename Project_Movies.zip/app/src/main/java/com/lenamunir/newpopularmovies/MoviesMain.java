package com.lenamunir.newpopularmovies;

import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MoviesMain extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<List<list_item>> {


    private static final String URL_DATA = "";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;

    private List<list_item> listOfMovies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_main);

        //initialize the recycler view
         recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        //set the fixed size of each item of the recycler view
        recyclerView.setHasFixedSize(true);

        //create and set the LAyout Manager on recycler view to define its look
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //initialize the @listOfMovies List which will store all the items of the recycler view
        listOfMovies = new ArrayList<>();


        //initialise adapter
        adapter = new MyAdapter(this, new ArrayList<listOfMovies>());

        //now set the adapter to the recycler view

    }

    @Override
    public Loader<List<list_item>> onCreateLoader(int id, Bundle args) {
        // Create a new loader for the given URL
        return new MovieLoader(this, MOVIE_QUERY_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<list_item>> loader, List<list_item> data) {
        adapter.clear();

    }

    @Override
    public void onLoaderReset(Loader<List<list_item>> loader) {
        adapter.clear();

    }
}
