package com.lenamunir.newpopularmovies;
import android.app.LauncherActivity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{

    //Let's define a list of data for adapter to hold

    private List<list_item> listOfData = new ArrayList<>();
    private Context context;

    public MyAdapter(List<list_item> listOfData, Context context) {
        this.listOfData = listOfData;
        this.context = context;
    }

        @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        //Create a view object with info about layout to be inflated
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new ViewHolder(v);
    }

    //This method should update the contents of the itemView to reflect the item at the given position.
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        //Bind the actual data with image view &
        //get the current object of the list at a current position

        Picasso.with(holder.moviePoster.getContext())
                .load(QueryUtils.buildPosterUrl(listOfData.get(position).getPosterPath()))
                .placeholder(R.drawable.__________)
                .into(holder.moviePoster);

    }

    @Override
    public int getItemCount() {
        //Return the number of elements of the list
        return listOfData.size();
    }

    //This class describes an item view and metadata about its place within the RecyclerView.
    public class ViewHolder extends RecyclerView.ViewHolder implements View.onClickListener{

        // Now that we have a ViewHolder object, it knows which layout we're working with..
        // but it still needs to be told WHERE exactly within the layout to place the data

        //Hence, I'm creating a TextView & finding it's reference to the text view of
        // the list_item.xml file inside ViewHolder class' constructor.

        public ImageView moviePoster;

        public ViewHolder(View itemView) {
            super(itemView);

            moviePoster = (ImageView) itemView.findViewById(R.id.iv_movie);
            itemView.setOnClickListener(this);
        }

        //Using onClick() method and Intent, I'm starting new activity of the movie details
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(view.getContext(), DetailsActivity.class);
            Movie currentMovie = movies.get(getAdapterPosition());
            intent.putExtra("movieDetails", currentMovie);
            view.getContext().startActivity(intent);
        }
    }
}
