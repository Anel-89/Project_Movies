package com.lenamunir.newpopularmovies;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;


public class MovieLoader extends AsyncTaskLoader<List<list_item>> {

    //Query URL
    private String mUrl;

    public MovieLoader(Context context, String url) {
        super(context);
        mUrl=url;
    }

    @Override
    public List<list_item> loadInBackground() {
       //check if query URL is valid
        if(mUrl==null){
        return null;}

        //perform a network request & return list of movies
        List<list_item> movies = QueryUtils.fetchMoviePosters(mUrl);
        return movies;

    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }
}
