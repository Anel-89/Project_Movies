package com.lenamunir.newpopularmovies;


public class list_item {

    public list_item(String imageUrl) {

        ImageUrl = imageUrl;
    }

     public String getImageUrl() {
        return ImageUrl;
    }

    String ImageUrl;

}
